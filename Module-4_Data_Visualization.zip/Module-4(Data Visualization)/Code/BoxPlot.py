import pandas as pd
import matplotlib.pyplot as plt
import sys
import numpy as np
#create dataframe from csv
df=pd.read_csv(sys.argv[1], header=0)
plotMap=[]

#create a list of lists where each list will have a corresponding box plot
plotMap.append(np.log(df['UPTO 2000-01 - NUMBER'].dropna().tolist()))
plotMap.append(np.log(df['DURING 2001-02 - NUMBER'].dropna().tolist()))
plotMap.append(np.log(df['DURING 2002-03 - NUMBER'].dropna().tolist()))
plotMap.append(np.log(df['DURING 2003-04 - NUMBER'].dropna().tolist()))
plotMap.append(np.log(df['DURING 2004-05 - NUMBER'].dropna().tolist()))
plotMap.append(np.log(df['DURING 2005-06 - NUMBER'].dropna().tolist()))
plotMap.append(np.log(df['DURING 2006-07 - NUMBER'].dropna().tolist()))
plotMap.append(np.log(df['TOTAL - NUMBER'].dropna().tolist()))

#plotting
plt.boxplot(plotMap)

#specifying labels
plt.xticks([1,2,3,4,5, 6, 7, 8],["2000-01","2001-02", "2002-03", "2003-04", "2004-05", "2005-06", "2006-07", "2000-07"])
plt.xlabel("Year")
plt.ylabel("Number of Deep Tubewells Constructed (in log)")


plt.legend()
plt.show()