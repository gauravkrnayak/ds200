import pandas as pd
import matplotlib.pyplot as plt
import sys

def plottingScatterPlot(col1, col2, title) : 
    plt.bar([1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29],col1,color='#ddbbaa',label="bar-label")   
    #specify labels on xticks
    plt.xticks([1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29],col2,rotation='vertical')
    plt.xlabel("States")
    plt.ylabel("Number of Deep Tubewells")
    plt.title(title)    
    #enabling legend
    plt.legend()
    plt.show()
    
#reading data frame from a csv file
df=pd.read_csv(sys.argv[1], header=0)
plottingScatterPlot(df['UPTO 2000-01 - NUMBER'], df['STATE'], "Bar Plot of Total Number of Tubewells constructed in each state in India (from 2000 to 2001)")
plottingScatterPlot(df['DURING 2001-02 - NUMBER'], df['STATE'], "Bar Plot of Total Number of Tubewells constructed in each state in India (from 2001 to 2002)")
plottingScatterPlot(df['DURING 2002-03 - NUMBER'], df['STATE'], "Bar Plot of Total Number of Tubewells constructed in each state in India (from 2002 to 2003)")
plottingScatterPlot(df['DURING 2003-04 - NUMBER'], df['STATE'], "Bar Plot of Total Number of Tubewells constructed in each state in India (from 2003 to 2004)")
plottingScatterPlot(df['DURING 2004-05 - NUMBER'], df['STATE'], "Bar Plot of Total Number of Tubewells constructed in each state in India (from 2004 to 2005)")
plottingScatterPlot(df['DURING 2005-06 - NUMBER'], df['STATE'], "Bar Plot of Total Number of Tubewells constructed in each state in India (from 2005 to 2006)")
plottingScatterPlot(df['DURING 2006-07 - NUMBER'], df['STATE'], "Bar Plot of Total Number of Tubewells constructed in each state in India (from 2006 to 2007)")
plottingScatterPlot(df['TOTAL - NUMBER'], df['STATE'], "Bar Plot of Total Number of Tubewells constructed in each state in India (from 2000 to 2007)")