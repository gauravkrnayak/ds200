import pandas as pd
import matplotlib.pyplot as plt
import sys

def plottingScatterPlot(col1, col2, title) : 
    #plot scatter with first column as x values and second column as y values
    plt.scatter(col1,col2,color='#dd12dd',label="scatter-label")
    #specifying labels
    plt.xlabel("Total Number of Deep Tubewells")
    plt.ylabel("Total Cost (in Crore)")
    plt.title(title)
    #enable legend
    plt.legend()
    plt.show()
    
#create dataframe
df=pd.read_csv(sys.argv[1], header=0)

df['UPTO 2000-01 - COST'] = df['UPTO 2000-01 - COST']/1000000.0 #from Rs to Crore
df['DURING 2001-02 - COST'] = df['DURING 2001-02 - COST']/1000000.0 #from Rs to Crore
df['DURING 2002-03 - COST'] = df['DURING 2002-03 - COST']/1000000.0 #from Rs to Crore
df['DURING 2003-04 COST'] = df['DURING 2003-04 COST']/1000000.0 #from Rs to Crore
df['DURING 2004-05 - COST'] = df['DURING 2004-05 - COST']/1000000.0 #from Rs to Crore
df['DURING 2005-06 - COST'] = df['DURING 2005-06 - COST']/1000000.0 #from Rs to Crore
df['DURING 2006-07 COST'] = df['DURING 2006-07 COST']/1000000.0 #from Rs to Crore
df['TOTAL - COST'] = df['TOTAL - COST']/1000000.0 #from Rs to Crore

plottingScatterPlot(df['UPTO 2000-01 - NUMBER'], df['UPTO 2000-01 - COST'], "Scatter Plot of Total Number of Tubewells and the total Cost in their Construction in India (from 2000 to 2001)")
plottingScatterPlot(df['DURING 2001-02 - NUMBER'], df['DURING 2001-02 - COST'], "Scatter Plot of Total Number of Tubewells and the total Cost in their Construction in India (from 2001 to 2002)")
plottingScatterPlot(df['DURING 2002-03 - NUMBER'], df['DURING 2002-03 - COST'], "Scatter Plot of Total Number of Tubewells and the total Cost in their Construction in India (from 2002 to 2003)")
plottingScatterPlot(df['DURING 2003-04 - NUMBER'], df['DURING 2003-04 COST'], "Scatter Plot of Total Number of Tubewells and the total Cost in their Construction in India (from 2003 to 2004)")
plottingScatterPlot(df['DURING 2004-05 - NUMBER'], df['DURING 2004-05 - COST'], "Scatter Plot of Total Number of Tubewells and the total Cost in their Construction in India (from 2004 to 2005)")
plottingScatterPlot(df['DURING 2005-06 - NUMBER'], df['DURING 2005-06 - COST'], "Scatter Plot of Total Number of Tubewells and the total Cost in their Construction in India (from 2005 to 2006)")
plottingScatterPlot(df['DURING 2006-07 - NUMBER'], df['DURING 2006-07 COST'], "Scatter Plot of Total Number of Tubewells and the total Cost in their Construction in India (from 2006 to 2007)")
plottingScatterPlot(df['TOTAL - NUMBER'], df['TOTAL - COST'], "Scatter Plot of Total Number of Tubewells and the total Cost in their Construction in India (from 2000 to 2007)")

